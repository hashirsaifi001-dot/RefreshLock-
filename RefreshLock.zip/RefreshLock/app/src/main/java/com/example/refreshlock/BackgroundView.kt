package com.example.refreshlock

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

class BackgroundView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun blob(cv: Canvas, x: Float, y: Float, r: Float, color: Int) {
        p.shader = RadialGradient(x, y, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r, p)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = LinearGradient(
            0f, 0f, 0f, h, 0xFF04060B.toInt(), 0xFF0B1224.toInt(), Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, 0f, w, h, p)
        blob(cv, w * 0.15f, h * 0.22f, w * 0.8f, 0x4D5CE1E6)
        blob(cv, w * 0.95f, h * 0.55f, w * 0.8f, 0x4D8B5CF6)
        blob(cv, w * 0.30f, h * 0.95f, w * 0.7f, 0x4D3B82F6)
    }
}
