package com.example.refreshlock

object Thermal {
    val RATES = intArrayOf(120, 90, 60)

    // SoC / battery thresholds (deg C): level 1 = 90 Hz, level 2 = 60 Hz
    private const val SOC_90 = 48
    private const val SOC_60 = 55
    private const val BAT_90 = 40
    private const val BAT_60 = 44
    private const val HYST = 3

    private fun lvl(t: Int?, a: Int, b: Int): Int = when {
        t == null -> 0
        t >= b -> 2
        t >= a -> 1
        else -> 0
    }

    fun next(current: Int, soc: Int?, bat: Int?): Int {
        val up = maxOf(lvl(soc, SOC_90, SOC_60), lvl(bat, BAT_90, BAT_60))
        val stay = maxOf(
            lvl(soc, SOC_90 - HYST, SOC_60 - HYST),
            lvl(bat, BAT_90 - HYST, BAT_60 - HYST)
        )
        return maxOf(up, minOf(current, stay))
    }
}
