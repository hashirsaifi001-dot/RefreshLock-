package com.example.refreshlock

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var circle: CircleView
    private lateinit var socV: TextView
    private lateinit var batV: TextView
    private lateinit var hint: TextView
    private val h = Handler(Looper.getMainLooper())

    private val prefs by lazy { getSharedPreferences("s", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val poll = object : Runnable {
        override fun run() {
            Thread {
                val t = Root.temps()
                h.post {
                    socV.text = t.soc?.let { "$it°" } ?: "—"
                    batV.text = t.bat?.let { "$it°" } ?: "—"
                    sync()
                }
            }.start()
            h.postDelayed(this, 3000)
        }
    }

    private fun card(title: String): Pair<LinearLayout, TextView> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0x38FFFFFF, 0x0DFFFFFF)
            ).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), 0x40FFFFFF)
            }
        }
        val t = TextView(this).apply {
            text = title
            textSize = 12f
            letterSpacing = 0.15f
            setTextColor(0x99FFFFFF.toInt())
        }
        val v = TextView(this).apply {
            text = "—"
            textSize = 32f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        }
        box.addView(t)
        box.addView(v)
        return Pair(box, v)
    }

    private fun spacer() = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = FrameLayout(this)
        root.addView(
            BackgroundView(this),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        col.setOnApplyWindowInsetsListener { v, ins ->
            val i = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(i.left + dp(24), i.top + dp(24), i.right + dp(24), i.bottom + dp(24))
            ins
        }

        col.addView(TextView(this).apply {
            text = "REFRESH LOCK"
            textSize = 13f
            letterSpacing = 0.3f
            setTextColor(0x99FFFFFF.toInt())
        })
        col.addView(spacer())

        circle = CircleView(this).apply {
            isClickable = true
            setOnClickListener { toggle() }
        }
        col.addView(circle, LinearLayout.LayoutParams(dp(280), dp(280)))

        hint = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0x99FFFFFF.toInt())
            setPadding(0, dp(20), 0, 0)
        }
        col.addView(hint)
        col.addView(spacer())

        val (socCard, sv) = card("SOC")
        val (batCard, bv) = card("BATTERY")
        socV = sv
        batV = bv
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { rightMargin = dp(6) }
        val lp2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { leftMargin = dp(6) }
        row.addView(socCard, lp1)
        row.addView(batCard, lp2)
        col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(TextView(this).apply {
            text = "90 Hz at SoC 48° / battery 40°\n60 Hz at SoC 55° / battery 44°"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0x66FFFFFF)
            setPadding(0, dp(16), 0, 0)
        })

        root.addView(
            col,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)
    }

    private fun toggle() {
        val on = !prefs.getBoolean("on", false)
        prefs.edit().putBoolean("on", on).putInt("level", 0).apply()
        val svc = Intent(this, ThermalService::class.java)
        if (on) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(svc)
        } else {
            stopService(svc)
        }
        sync()
    }

    private fun sync() {
        val on = prefs.getBoolean("on", false)
        val level = prefs.getInt("level", 0).coerceIn(0, 2)
        circle.set(on, Thermal.RATES[level])
        hint.text = if (on) {
            when (level) {
                0 -> "Locked at 120 Hz"
                1 -> "Hot: dropped to 90 Hz"
                else -> "Very hot: dropped to 60 Hz"
            }
        } else {
            "Tap the circle to lock 120 Hz"
        }
    }

    override fun onResume() {
        super.onResume()
        sync()
        h.post(poll)
    }

    override fun onPause() {
        h.removeCallbacks(poll)
        super.onPause()
    }
}
