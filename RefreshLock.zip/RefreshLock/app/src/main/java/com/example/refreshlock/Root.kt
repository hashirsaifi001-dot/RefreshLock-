package com.example.refreshlock

object Root {
    data class Temps(val soc: Int?, val bat: Int?)

    fun run(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        out
    } catch (e: Exception) {
        ""
    }

    fun lock(hz: Int) {
        run("settings put system min_refresh_rate $hz.0; settings put system peak_refresh_rate $hz.0")
    }

    fun release() {
        run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
    }

    fun temps(): Temps {
        val cmd = "for z in /sys/class/thermal/thermal_zone*; do echo \"\$(cat \$z/type) \$(cat \$z/temp)\"; done; " +
            "echo \"zzbat \$(cat /sys/class/power_supply/battery/temp)\""
        var soc: Int? = null
        var bat: Int? = null
        for (line in run(cmd).lines()) {
            val i = line.lastIndexOf(' ')
            if (i < 0) continue
            val type = line.substring(0, i).trim().lowercase()
            val v = line.substring(i + 1).trim().toIntOrNull() ?: continue
            if (type == "zzbat") {
                bat = if (v > 100) v / 10 else v
            } else if (type.contains("soc") || type.contains("cpu")) {
                val c = if (v > 1000) v / 1000 else v
                if (c in 10..120) soc = maxOf(soc ?: 0, c)
            }
        }
        return Temps(soc, bat)
    }
}
