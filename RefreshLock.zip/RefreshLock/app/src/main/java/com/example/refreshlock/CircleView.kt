package com.example.refreshlock

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View

class CircleView(c: Context) : View(c) {
    companion object {
        val OFF = 0xFF8A97A8.toInt()
        val CYAN = 0xFF5CE1E6.toInt()
        val AMBER = 0xFFFFB84D.toInt()
        val RED = 0xFFFF5A5F.toInt()
    }

    private var hz = 120
    private var anim = 0f
    private var tint = OFF
    private var fromAnim = 0f
    private var fromTint = OFF
    private var toAnim = 0f
    private var toTint = OFF
    private var animator: ValueAnimator? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val path = Path()
    private val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val ev = ArgbEvaluator()
    private val density = c.resources.displayMetrics.density

    private fun a(color: Int, alpha: Int) =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    fun set(on: Boolean, newHz: Int) {
        val tTint = if (!on) OFF else when (newHz) { 120 -> CYAN; 90 -> AMBER; else -> RED }
        val tAnim = if (on) 1f else 0f
        hz = newHz
        if (tAnim == toAnim && tTint == toTint) {
            invalidate()
            return
        }
        fromAnim = anim
        fromTint = tint
        toAnim = tAnim
        toTint = tTint
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            addUpdateListener {
                val f = it.animatedFraction
                anim = fromAnim + (toAnim - fromAnim) * f
                tint = ev.evaluate(f, fromTint, toTint) as Int
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        val gR = minOf(w, h) / 2
        val r = gR * 0.78f

        // outer glow
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(
            cx, cy, gR,
            intArrayOf(a(tint, (30 + 110 * anim).toInt()), a(tint, 0)),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, gR, p)

        // glass body
        p.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.45f, r * 1.6f,
            intArrayOf(
                a(Color.WHITE, 70),
                a(tint, (25 + 40 * anim).toInt()),
                a(tint, (40 + 60 * anim).toInt())
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r, p)

        // rim light
        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            a(Color.WHITE, 200), a(tint, 60), Shader.TileMode.CLAMP
        )
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * density
        cv.drawCircle(cx, cy, r - density, p)

        // top highlight
        cv.save()
        path.reset()
        path.addCircle(cx, cy, r, Path.Direction.CW)
        cv.clipPath(path)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, cy - r, 0f, cy, a(Color.WHITE, 90), a(Color.WHITE, 0), Shader.TileMode.CLAMP
        )
        cv.drawOval(RectF(cx - r * 0.75f, cy - r * 0.97f, cx + r * 0.75f, cy - r * 0.1f), p)
        cv.restore()

        // text
        tp.typeface = light
        tp.color = Color.WHITE
        if (toAnim > 0.5f) {
            tp.letterSpacing = 0f
            tp.textSize = r * 0.7f
            cv.drawText("$hz", cx, cy + r * 0.2f, tp)
            tp.textSize = r * 0.17f
            tp.letterSpacing = 0.2f
            tp.color = a(Color.WHITE, 180)
            cv.drawText("HZ  LOCKED", cx, cy + r * 0.52f, tp)
        } else {
            tp.letterSpacing = 0.05f
            tp.textSize = r * 0.45f
            cv.drawText("OFF", cx, cy + r * 0.12f, tp)
            tp.textSize = r * 0.15f
            tp.letterSpacing = 0.2f
            tp.color = a(Color.WHITE, 140)
            cv.drawText("TAP TO LOCK", cx, cy + r * 0.45f, tp)
        }
    }
}
