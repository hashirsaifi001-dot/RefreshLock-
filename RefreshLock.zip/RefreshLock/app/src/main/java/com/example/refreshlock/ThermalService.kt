package com.example.refreshlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

class ThermalService : Service() {
    private var thread: Thread? = null
    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("rl", "Refresh Lock", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, notif("Starting..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (thread == null) {
            running = true
            thread = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun notif(text: String): Notification =
        Notification.Builder(this, "rl")
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .setContentTitle("Refresh Lock")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun loop() {
        val prefs = getSharedPreferences("s", MODE_PRIVATE)
        val nm = getSystemService(NotificationManager::class.java)
        var level = 0
        var applied = -1
        var tick = 0
        while (running) {
            val t = Root.temps()
            level = Thermal.next(level, t.soc, t.bat)
            if (level != applied || tick % 5 == 0) {
                Root.lock(Thermal.RATES[level])
                applied = level
            }
            prefs.edit().putInt("level", level).apply()
            nm.notify(
                1,
                notif("Locked ${Thermal.RATES[level]} Hz  |  SoC ${t.soc ?: "?"}°  Battery ${t.bat ?: "?"}°")
            )
            tick++
            try { Thread.sleep(3000) } catch (e: InterruptedException) { break }
        }
    }

    override fun onDestroy() {
        running = false
        thread?.interrupt()
        thread = null
        Root.release()
        super.onDestroy()
    }
}
